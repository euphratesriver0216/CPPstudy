#include "child.h"

child::child()
{
	_freeMoney = 5;

	cout << "�ڽ��� �ֿ� �� : " << _freeMoney << endl;

	_familyMoney = 3;

	_motherMoney = 1;

}

child::~child()
{
}
