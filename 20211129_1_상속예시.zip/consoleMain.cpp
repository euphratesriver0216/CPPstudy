#include "child.h"

int main()
{
	child cd;

	return 0;
}